# astro-local-config (SELF-CONTAINED)

A complete local bundle that provides:
- Traefik reverse proxy (HTTP 80 / HTTPS 443) for `*.localhost`
- A private Docker registry at **https://registry.localhost**
- mkcert helper to issue local TLS certs
- Optional Ansible playbook to bootstrap idempotently

> Works on Win/WSL2 with Docker Desktop. No hosts-file edits. No external DNS.

## Quick start (no Ansible)

```bash
cd traefik-bundle
# 1) Generate/refresh local certs (one-time, repeat if needed)
bash ./scripts/mkcert-generate.sh

# 2) Start Traefik + registry
docker compose up -d
```

Test the registry:
```bash
docker login registry.localhost    # anonymous OK unless you add basic auth
docker pull busybox
docker tag busybox registry.localhost/demo/busybox:latest
docker push registry.localhost/demo/busybox:latest
docker pull registry.localhost/demo/busybox:latest
```

## Optional: Ansible bootstrap

```bash
cd ansible
ansible-playbook -i inventory/hosts.ini site.yml
```

This will:
- check mkcert, generate certs under `traefik-bundle/tls/`
- start/refresh the Traefik stack (including the registry)
